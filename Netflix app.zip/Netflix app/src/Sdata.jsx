const Sdata = [
  {
    sname: "Money Heist",
    imgsrc:
      "https://images-na.ssl-images-amazon.com/images/I/81pxUkkhx-L._SL1500_.jpg",
    title: "Netflix Original Series",
    link: "https://www.netflix.com/in/title/80192098",
  },

  {
    sname: "DARK",
    imgsrc:
      "https://mir-s3-cdn-cf.behance.net/project_modules/1400_opt_1/416a0260154325.5a3e6ee26cbc3.jpg",
    title: "Netflix Original Series",
    link: "https://www.netflix.com/in/title/80100172",
  },

  {
    sname: "Stranger Things",
    imgsrc:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRpGvzVGudh9ITs9VFf3OqBBXWUNVEsRgk-LQ&usqp=CAU",
    title: "Netflix Original Series",
    link: "https://www.netflix.com/in/title/80057281",
  },
  {
    sname: "Breaking Bad",
    imgsrc:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ5KlcxslotycPA1j9gUqdQs_LOZt_Ry-Vg8Q&usqp=CAU",
    title: "Netflix Original Series",
    link: "https://www.netflix.com/in/title/70143836",
  },
  {
    sname: "Peaky Blinders",
    imgsrc:
      "https://cdn.shopify.com/s/files/1/0051/8959/9321/products/Peaky-Blinders2_39f7d689-5797-483a-91ed-586835c7be3c_grande.png?v=1569064888",
    title: "Netflix Original Series",
    link: "https://www.netflix.com/in/title/80002479",
  },
];

export default Sdata;
