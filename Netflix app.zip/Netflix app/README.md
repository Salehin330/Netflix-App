# Netflix-Series-List
A webpage that displays the best web series of Netflix in 2020. 
